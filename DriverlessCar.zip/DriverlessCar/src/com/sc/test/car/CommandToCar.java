package com.sc.test.car;

public interface CommandToCar {
	
	public void executeCommand();

}
