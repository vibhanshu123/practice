package com.sc.test.states;
public interface State {
	
	public void turnleft();
	public void turnright();
	public void move();

}
